import { Player } from "../player/player"

export class Team {
    id!: number
    name!: String
    player!: Array<Player>
}
