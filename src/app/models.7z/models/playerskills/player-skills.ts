export class PlayerSkills {
    id!: number
    style!: String
    winPercentage!: Float32Array
    winStreak!: number
}
