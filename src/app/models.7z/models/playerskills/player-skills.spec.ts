import { PlayerSkills } from './player-skills';

describe('PlayerSkills', () => {
  it('should create an instance', () => {
    expect(new PlayerSkills()).toBeTruthy();
  });
});
